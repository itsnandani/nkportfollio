/* ============================================================
   Nandani Kumari — Portfolio
   script.js — Mobile navigation toggle
   ------------------------------------------------------------
   Used only for the accessible collapsible mobile navigation.
   The menu can be opened/closed with keyboard, updates
   aria-expanded, and closes after a navigation link is selected.
   ============================================================ */

(function () {
    'use strict';

    var navToggle = document.getElementById('navToggle');
    var navMenu = document.getElementById('navMenu');

    if (!navToggle || !navMenu) return;

    /* Toggle the mobile menu open / closed */
    function toggleMenu() {
        var isOpen = navToggle.getAttribute('aria-expanded') === 'true';
        navToggle.setAttribute('aria-expanded', String(!isOpen));
        navMenu.classList.toggle('open');
    }

    /* Close the mobile menu */
    function closeMenu() {
        navToggle.setAttribute('aria-expanded', 'false');
        navMenu.classList.remove('open');
    }

    navToggle.addEventListener('click', function (e) {
        e.stopPropagation();
        toggleMenu();
    });

    /* Close menu when a nav link is clicked */
    var navLinks = navMenu.querySelectorAll('a');
    navLinks.forEach(function (link) {
        link.addEventListener('click', function () {
            closeMenu();
        });
    });

    /* Close menu when clicking outside */
    document.addEventListener('click', function (e) {
        if (!navMenu.contains(e.target) && !navToggle.contains(e.target)) {
            closeMenu();
        }
    });

    /* Close menu on Escape key */
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closeMenu();
            navToggle.focus();
        }
    });

    /* Close menu when resizing to desktop */
    window.addEventListener('resize', function () {
        if (window.innerWidth >= 600) {
            closeMenu();
        }
    });
})();
